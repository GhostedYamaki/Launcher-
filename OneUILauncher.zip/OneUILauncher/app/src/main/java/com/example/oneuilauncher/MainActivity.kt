package com.example.oneuilauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {

    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
            LaunchedEffect(refresh) { apps = withContext(Dispatchers.IO) { loadApps() } }
            LauncherScreen(apps) { app ->
                packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++ // pick up newly installed / removed apps
    }

    private fun loadApps(): List<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = it.loadIcon(pm).toBitmap(120, 120).asImageBitmap()
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
fun LauncherScreen(apps: List<AppInfo>, onLaunch: (AppInfo) -> Unit) {
    val dark = isSystemInDarkTheme()
    val scope = rememberCoroutineScope()
    val progress = remember { Animatable(0f) } // 0 = home, 1 = drawer open
    val oneUiSpring = spring<Float>(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val heightPx = with(LocalDensity.current) { maxHeight.toPx() }
        val open by remember { derivedStateOf { progress.value > 0f } }

        val settle: suspend (Float) -> Unit = { velocity ->
            val target = when {
                velocity < -1000f -> 1f
                velocity > 1000f -> 0f
                progress.value > 0.5f -> 1f
                else -> 0f
            }
            progress.animateTo(target, oneUiSpring)
        }
        val dragState = rememberDraggableState { delta ->
            scope.launch {
                progress.snapTo((progress.value - delta / (heightPx * 0.8f)).coerceIn(0f, 1f))
            }
        }

        BackHandler(enabled = open) { scope.launch { progress.animateTo(0f, oneUiSpring) } }

        // Home layer: scales back and fades as the drawer comes up
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val p = progress.value
                    scaleX = 1f - 0.08f * p
                    scaleY = 1f - 0.08f * p
                    alpha = 1f - p
                }
                .draggable(dragState, Orientation.Vertical, onDragStopped = { settle(it) })
        ) {
            HomeContent(dock = apps.take(4), onLaunch = onLaunch)
        }

        // Drawer layer
        if (open) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.25f))
                    .graphicsLayer { alpha = progress.value }
            )
            Drawer(
                apps = apps,
                dark = dark,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { translationY = (1f - progress.value) * heightPx },
                headerModifier = Modifier.draggable(
                    dragState, Orientation.Vertical, onDragStopped = { settle(it) }
                ),
                onLaunch = {
                    onLaunch(it)
                    scope.launch { progress.snapTo(0f) }
                }
            )
        }
    }
}

@Composable
fun HomeContent(dock: List<AppInfo>, onLaunch: (AppInfo) -> Unit) {
    val timeFmt = remember { SimpleDateFormat("h:mm", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()) }
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(10_000)
        }
    }
    val shadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset(0f, 2f), 8f)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(72.dp))
        Text(
            timeFmt.format(now),
            style = TextStyle(
                color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light, shadow = shadow
            )
        )
        Text(
            dateFmt.format(now),
            style = TextStyle(color = Color.White, fontSize = 17.sp, shadow = shadow)
        )
        Spacer(Modifier.weight(1f))
        Box(
            Modifier
                .width(36.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.6f))
        )
        Row(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .fillMaxWidth()
                .background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(32.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            dock.forEach { AppIcon(it, Color.White, showLabel = false) { onLaunch(it) } }
        }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    dark: Boolean,
    modifier: Modifier,
    headerModifier: Modifier,
    onLaunch: (AppInfo) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val surface = if (dark) Color(0xF0121212) else Color(0xF2F6F6F6)
    val field = if (dark) Color(0xFF2A2A2A) else Color.White
    val text = if (dark) Color(0xFFEDEDED) else Color(0xFF1A1A1A)
    val hint = text.copy(alpha = 0.5f)
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(
        modifier
            .statusBarsPadding()
            .padding(top = 24.dp)
            .background(surface, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
    ) {
        Column(headerModifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(text.copy(alpha = 0.25f))
            )
            Spacer(Modifier.height(14.dp))
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = text, fontSize = 16.sp),
                cursorBrush = SolidColor(text),
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(field, RoundedCornerShape(24.dp))
                    .padding(horizontal = 20.dp),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) Text("Search apps", color = hint, fontSize = 16.sp)
                        inner()
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered, key = { it.pkg }) { app ->
                AppIcon(app, text, showLabel = true) { onLaunch(app) }
            }
        }
    }
}

@Composable
fun AppIcon(app: AppInfo, textColor: Color, showLabel: Boolean, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    Column(
        Modifier
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(vertical = 10.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
        )
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                app.label,
                color = textColor,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width(72.dp)
            )
        }
    }
}
